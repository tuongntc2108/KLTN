"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Mail, Lock, Eye, EyeOff, Shield, GraduationCap, Building2, UserCheck, Chrome } from "lucide-react"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [userType, setUserType] = useState<"training" | "student" | "admin">("student")

  const userTypes = [
    {
      id: "student",
      label: "Học viên",
      icon: GraduationCap,
      description: "Nhận và quản lý chứng chỉ NFT",
      color: "bg-blue-100 text-blue-800",
    },
    {
      id: "training",
      label: "Đơn vị đào tạo",
      icon: Building2,
      description: "Cấp phát và quản lý chứng chỉ",
      color: "bg-green-100 text-green-800",
    },
    {
      id: "admin",
      label: "Quản trị viên",
      icon: Shield,
      description: "Quản lý toàn bộ hệ thống",
      color: "bg-purple-100 text-purple-800",
    },
  ]

  const handleGoogleLogin = () => {
    // Simulate Google OAuth login
    console.log("[v0] Google login initiated for user type:", userType)

    // Redirect based on user type
    const redirectPaths = {
      student: "/dashboard/student",
      training: "/dashboard/training",
      admin: "/dashboard/admin",
    }

    // In real implementation, this would handle OAuth flow
    window.location.href = redirectPaths[userType]
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold">CertChain</h1>
          </div>
          <h2 className="text-xl font-semibold text-gray-900">Đăng nhập hệ thống</h2>
          <p className="text-gray-600">Chọn loại tài khoản và đăng nhập để tiếp tục</p>
        </div>

        {/* User Type Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Chọn loại tài khoản</CardTitle>
            <CardDescription>Vui lòng chọn vai trò phù hợp với bạn</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {userTypes.map((type) => {
              const Icon = type.icon
              return (
                <div
                  key={type.id}
                  className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                    userType === type.id ? "border-primary bg-primary/5" : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setUserType(type.id as any)}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${type.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{type.label}</h3>
                        {userType === type.id && (
                          <Badge variant="default" className="text-xs">
                            <UserCheck className="w-3 h-3 mr-1" />
                            Đã chọn
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{type.description}</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>

        {/* Login Form */}
        <Card>
          <CardHeader>
            <CardTitle>Đăng nhập</CardTitle>
            <CardDescription>Sử dụng tài khoản Google để đăng nhập an toàn</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Google Login Button */}
            <Button
              onClick={handleGoogleLogin}
              className="w-full h-12 bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
              variant="outline"
            >
              <Chrome className="w-5 h-5 mr-3" />
              Đăng nhập với Google
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Hoặc đăng nhập bằng email</span>
              </div>
            </div>

            {/* Email/Password Form */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input id="email" type="email" placeholder="your.email@example.com" className="pl-10" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mật khẩu</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Nhập mật khẩu"
                    className="pl-10 pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <input
                    id="remember"
                    type="checkbox"
                    className="w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
                  />
                  <Label htmlFor="remember" className="text-sm">
                    Ghi nhớ đăng nhập
                  </Label>
                </div>
                <Link href="/auth/forgot-password" className="text-sm text-primary hover:underline">
                  Quên mật khẩu?
                </Link>
              </div>

              <Button className="w-full">Đăng nhập</Button>
            </div>

            <div className="text-center text-sm text-gray-600">
              Chưa có tài khoản?{" "}
              <Link href="/auth/register" className="text-primary hover:underline font-medium">
                Đăng ký ngay
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Security Notice */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-1">Bảo mật cao với Blockchain</p>
                <p>
                  Hệ thống sử dụng công nghệ blockchain để đảm bảo tính toàn vẹn và bảo mật cho tất cả chứng chỉ số.
                  Thông tin của bạn được mã hóa và bảo vệ tuyệt đối.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-xs text-gray-500">
          <p>
            Bằng việc đăng nhập, bạn đồng ý với{" "}
            <Link href="/terms" className="text-primary hover:underline">
              Điều khoản sử dụng
            </Link>{" "}
            và{" "}
            <Link href="/privacy" className="text-primary hover:underline">
              Chính sách bảo mật
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
