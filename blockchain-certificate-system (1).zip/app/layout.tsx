import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { AIChatbot } from "@/components/ai/chatbot"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"

export const metadata: Metadata = {
  title: "CertChain - Hệ thống chứng chỉ số Blockchain",
  description: "Hệ thống cấp phát chứng chỉ số an toàn và minh bạch sử dụng công nghệ Blockchain và NFT",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="vi">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        {children}
        <AIChatbot />
        <Toaster />
        <Analytics />
      </body>
    </html>
  )
}
